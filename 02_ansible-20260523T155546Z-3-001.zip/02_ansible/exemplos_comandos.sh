#Comandos Ansible

# Verificar a configuração dos hosts
ansible servers -m setup

# Executar um comando manualmente
ansible web -m apt -a "name=wget state=absent" --become

# Rodar um playbook
ansible-playbook playbook.yml

# Criar uma role
ansible galaxy init apache

Fontes
https://docs.ansible.com/
https://www.server-world.info/en/note?os=Ubuntu_24.04&p=ansible&f=1