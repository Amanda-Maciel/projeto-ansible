#!/bin/bash

# Configuração de acesso sem senha nas duas VMs
# Definição de variáveis
USER="vagrant"
PASSWORD="vagrant"
HOST_DESTINO=("ansible" "web")  # Altere para o IP ou hostname do destino
SSH_DIR="/home/$USER/.ssh"
KEY_FILE="$SSH_DIR/id_rsa"

# Gera a chave RSA caso ainda não exista
if [ ! -f "$KEY_FILE" ]; then
   sudo -u vagrant ssh-keygen -t rsa -b 4096 -f /home/vagrant/.ssh/id_rsa -N ''
fi

# Garante que o diretório ~/.ssh tenha a permissão necessária
chown -R $USER: $SSH_DIR

for elt in "${HOST_DESTINO[@]}"; do
  expect <<EOF
  spawn sudo -u vagrant ssh-copy-id -o StrictHostKeyChecking=no -i ${KEY_FILE}.pub ${USER}@$elt
  expect {
    "Are you sure you want to continue connecting" { send "yes\r"; exp_continue }
    "password:" { send "$PASSWORD\r" }
  }
  expect eof
EOF

  # Teste da conexão
  echo "teste de conexão $elt"
  ssh ${USER}@$elt "echo 'Acesso SSH sem senha, $elt!'"
done


